<?php
/**
 * user代表有关user的文字
 * index 代表index类中文字
 * 
 * 
 */
return array(
		'user_login_notLogin' => '您没有登录',
		'index_index_seoTitle' => 'WIIBOX 挖矿设置',
		'index_saveData_success' => '保存数据成功',
		'monitor_index_seoTitle' => 'WIIBOX 监控中心',
		'monitor_check_isMiningMachine' => '我就是矿机!',
		'upgrade_index_seoTitle' => 'BTC & LTC 升级中心',
		'login_index_seoTitle' => '用户登入',
		'login_index_loginFaild' => '登入失败',
		'login_index_pwdWrong' => '密码错误',		
);
