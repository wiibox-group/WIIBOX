<?php
    return array(
    	'hashrate_title' => 'Hashrate',
    	'status_title' => '运行状态',
    	'status_device' => '设备',
    	'status_state' => '状态',
    	'status_algorithm' => '算法',
    	'sha_runStatus' => 'SHA 运行状态',
    	'this_version' => '当前版本:',
    	'scrypt_runStatus' => 'SCRYPT 运行状态',
    );
