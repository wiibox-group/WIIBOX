<?php
    return array(
    			'wiibox_setting' => 'WIIBOX设置',
    			'setting_center' => '设置中心',
    			'localMonitoring' => '本地监控',
    			'remoteMonitoring' => '远程监控',
    			'selfTest' => '自检',
    			'restartNow' => '重启',
    			'running' => '正在运行',
    			'runningStop' => '停止10秒',
    			'btc&Ltc_setting' => 'BTC&LTC 挖矿设置',
    			'logout'=> '退出',
    );
