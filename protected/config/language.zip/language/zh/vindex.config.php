<?php
    return array(
    		'setting_center' => 'Setting! 设置中心',
    		'this_version' => '当前版本:',
    		'care' => '',
    		'optimal_setting' => '<strong>注意!</strong> 最佳设置是一个矿机对应一个矿工号！ ',
    		'why' => '为什么?',
    		'worker_apart' => '多个矿工号请用 英文半角"," 隔开！',
    		'sha_setting' => 'SHA设置 (不填写则不启动)',
    		'sha_MinePoolAddress' => 'SHA矿池地址',
    		'sha_workerNum' => 'SHA矿工号 (一个即可，多个矿工默认第一个)',
    		'sha_workerPwd' => 'SHA统一矿工密码',
    		
    		'scrypt_setting' => 'SCRYPT设置 (不填写则不启动)',
    		'scrypt_MinePoolAddress' => 'SCRYPT矿池地址',
    		'scrypt_workerNum' => 'SCRYPT矿工号 (一个即可，多个矿工默认第一个)',
    		'scrypt_workerPwd' => 'SCRYPT统一矿工密码',
    		
    		'runFrequency' => '运行频率:',
    		'frequencyTip' => '超频有风险，请谨慎对待',
    		'setting_save' => '保存设置',
    		'importantOption' => '重要操作!',
    		'setting_save_tip' => '保存后请重启程序!',
    		'restartProgram' => '重启程序'
    );
